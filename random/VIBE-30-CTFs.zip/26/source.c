#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    const char *pass = "open_sesame_brg9Sr";
    unsigned char enc[] = { 211, 204, 199, 192, 218, 198, 209, 195, 254, 213, 240, 245, 234, 244, 200, 252, 230, 196, 213, 226, 223, 182, 201, 252, 252, 248 };
    unsigned char k = 133;
    char flag[256];
    int i;
    for (i = 0; i < (int)(sizeof(enc)); i++) flag[i] = (char)(enc[i] ^ k);
    flag[i] = '\0';

    char input[256];
    printf("Password: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, pass) == 0) {
        printf("Access granted. Flag: %%s\n", flag);
        fflush(stdout);
        exit(0);
    }
    printf("Access denied.\n");
    fflush(stdout);
    exit(1);
}
