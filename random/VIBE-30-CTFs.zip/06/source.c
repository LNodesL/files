#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    unsigned char enc[] = { 232, 247, 252, 251, 225, 253, 234, 248, 197, 204, 217, 140, 246, 237, 203, 199, 231, 142, 236, 211, 253, 201, 249, 215, 243, 195 };
    unsigned char key = 190;
    char secret[27];
    for (int i = 0; i < 26; i++) secret[i] = enc[i] ^ key;
    secret[26] = '\0';

    char input[256];
    printf("Key check: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Invalid.\n");
    fflush(stdout);
    exit(1);
}
