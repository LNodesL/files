#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    char enc[] = "}Fb0oGXEcEPoCRvQc{FTC_EBIV";
    char secret[256];
    int n = (int)strlen(enc);
    for (int i = 0; i < n; i++) secret[i] = enc[n - 1 - i];
    secret[n] = '\0';

    char input[256];
    printf("Flag: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Nope.\n");
    fflush(stdout);
    exit(1);
}
