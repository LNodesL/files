#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    const char *pass = "open_sesame_B0pVid";
    unsigned char enc[] = { 227, 252, 247, 240, 234, 246, 225, 243, 206, 197, 207, 192, 212, 247, 135, 246, 198, 227, 192, 197, 215, 194, 253, 247, 242, 200 };
    unsigned char k = 181;
    char flag[256];
    int i;
    for (i = 0; i < (int)(sizeof(enc)); i++) flag[i] = (char)(enc[i] ^ k);
    flag[i] = '\0';

    char input[256];
    printf("Password: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, pass) == 0) {
        printf("Access granted. Flag: %%s\n", flag);
        fflush(stdout);
        exit(0);
    }
    printf("Access denied.\n");
    fflush(stdout);
    exit(1);
}
