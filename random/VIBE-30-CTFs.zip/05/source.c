#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    unsigned char enc[] = { 153, 134, 141, 138, 144, 140, 155, 137, 180, 181, 154, 156, 163, 160, 167, 189, 163, 185, 153, 188, 191, 248, 163, 186, 255, 178 };
    unsigned char key = 207;
    char secret[27];
    for (int i = 0; i < 26; i++) secret[i] = enc[i] ^ key;
    secret[26] = '\0';

    char input[256];
    printf("Key check: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Invalid.\n");
    fflush(stdout);
    exit(1);
}
