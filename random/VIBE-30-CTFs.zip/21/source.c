#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    char secret[27];
    secret[0] = 'V'; secret[1] = 'I'; secret[2] = 'B'; secret[3] = 'E'; secret[4] = '_'; secret[5] = 'C'; secret[6] = 'T'; secret[7] = 'F'; secret[8] = '{'; secret[9] = 'A'; secret[10] = 'e'; secret[11] = 'E'; secret[12] = 'A'; secret[13] = 'V'; secret[14] = '7'; secret[15] = 'O'; secret[16] = '5'; secret[17] = 'm'; secret[18] = 'D'; secret[19] = 'W'; secret[20] = 'q'; secret[21] = 'T'; secret[22] = 'c'; secret[23] = 'j'; secret[24] = 'l'; secret[25] = '}';
    secret[26] = '\0';

    char input[256];
    printf("Guess: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Wrong.\n");
    fflush(stdout);
    exit(1);
}
