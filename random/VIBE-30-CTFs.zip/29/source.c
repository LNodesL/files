#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define DELTA 15

int main() {
    unsigned char enc[] = { 101, 88, 81, 84, 110, 82, 99, 85, 138, 112, 88, 121, 83, 115, 134, 114, 116, 135, 71, 84, 88, 121, 64, 119, 80, 140 };
    char secret[256];
    int i;
    for (i = 0; i < (int)(sizeof(enc)); i++)
        secret[i] = (char)((enc[i] - DELTA + 256) & 0xFF);
    secret[i] = '\0';

    char input[256];
    printf("Flag: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Incorrect.\n");
    fflush(stdout);
    exit(1);
}
