#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    char secret[27];
    secret[0] = 'V'; secret[1] = 'I'; secret[2] = 'B'; secret[3] = 'E'; secret[4] = '_'; secret[5] = 'C'; secret[6] = 'T'; secret[7] = 'F'; secret[8] = '{'; secret[9] = 'E'; secret[10] = 'C'; secret[11] = '7'; secret[12] = 'D'; secret[13] = 'V'; secret[14] = 'S'; secret[15] = 'O'; secret[16] = 'A'; secret[17] = 'c'; secret[18] = 'g'; secret[19] = 'U'; secret[20] = 'W'; secret[21] = 'N'; secret[22] = '3'; secret[23] = 'K'; secret[24] = 'a'; secret[25] = '}';
    secret[26] = '\0';

    char input[256];
    printf("Guess: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Wrong.\n");
    fflush(stdout);
    exit(1);
}
