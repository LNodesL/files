#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    const char *pass = "open_sesame_HDP4WR";
    unsigned char enc[] = { 114, 109, 102, 97, 123, 103, 112, 98, 95, 82, 84, 71, 116, 69, 82, 116, 86, 85, 28, 101, 112, 76, 21, 105, 82, 89 };
    unsigned char k = 36;
    char flag[256];
    int i;
    for (i = 0; i < (int)(sizeof(enc)); i++) flag[i] = (char)(enc[i] ^ k);
    flag[i] = '\0';

    char input[256];
    printf("Password: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, pass) == 0) {
        printf("Access granted. Flag: %%s\n", flag);
        fflush(stdout);
        exit(0);
    }
    printf("Access denied.\n");
    fflush(stdout);
    exit(1);
}
