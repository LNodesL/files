#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define DELTA 26

int main() {
    unsigned char enc[] = { 112, 99, 92, 95, 121, 93, 110, 96, 149, 132, 143, 124, 125, 79, 77, 98, 95, 99, 100, 78, 131, 104, 127, 105, 133, 151 };
    char secret[256];
    int i;
    for (i = 0; i < (int)(sizeof(enc)); i++)
        secret[i] = (char)((enc[i] - DELTA + 256) & 0xFF);
    secret[i] = '\0';

    char input[256];
    printf("Flag: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Incorrect.\n");
    fflush(stdout);
    exit(1);
}
