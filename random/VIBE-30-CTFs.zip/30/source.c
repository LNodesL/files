#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define DELTA 19

int main() {
    unsigned char enc[] = { 105, 92, 85, 88, 114, 86, 103, 89, 142, 107, 88, 131, 73, 134, 127, 140, 96, 139, 96, 103, 90, 84, 70, 116, 132, 144 };
    char secret[256];
    int i;
    for (i = 0; i < (int)(sizeof(enc)); i++)
        secret[i] = (char)((enc[i] - DELTA + 256) & 0xFF);
    secret[i] = '\0';

    char input[256];
    printf("Flag: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Incorrect.\n");
    fflush(stdout);
    exit(1);
}
