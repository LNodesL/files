#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    char secret[27];
    secret[0] = 'V'; secret[1] = 'I'; secret[2] = 'B'; secret[3] = 'E'; secret[4] = '_'; secret[5] = 'C'; secret[6] = 'T'; secret[7] = 'F'; secret[8] = '{'; secret[9] = 'q'; secret[10] = 'N'; secret[11] = 's'; secret[12] = '1'; secret[13] = 'd'; secret[14] = 'W'; secret[15] = 'N'; secret[16] = '3'; secret[17] = 'N'; secret[18] = 'D'; secret[19] = 'G'; secret[20] = 'O'; secret[21] = 'B'; secret[22] = 'D'; secret[23] = 'd'; secret[24] = 's'; secret[25] = '}';
    secret[26] = '\0';

    char input[256];
    printf("Guess: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Wrong.\n");
    fflush(stdout);
    exit(1);
}
