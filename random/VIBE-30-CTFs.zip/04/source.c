#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    unsigned char enc[] = { 235, 244, 255, 248, 226, 254, 233, 251, 198, 209, 206, 247, 222, 241, 201, 248, 197, 196, 247, 248, 236, 215, 244, 229, 206, 192 };
    unsigned char key = 189;
    char secret[27];
    for (int i = 0; i < 26; i++) secret[i] = enc[i] ^ key;
    secret[26] = '\0';

    char input[256];
    printf("Key check: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Invalid.\n");
    fflush(stdout);
    exit(1);
}
