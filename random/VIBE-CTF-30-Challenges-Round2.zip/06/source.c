#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    unsigned char enc[] = { 238, 241, 250, 253, 231, 251, 236, 254, 195, 224, 242, 235, 209, 239, 141, 238, 252, 253, 128, 235, 237, 214, 224, 213, 204, 197 };
    unsigned char key = 184;
    char secret[27];
    for (int i = 0; i < 26; i++) secret[i] = enc[i] ^ key;
    secret[26] = '\0';

    char input[256];
    printf("Key check: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Invalid.\n");
    fflush(stdout);
    exit(1);
}
