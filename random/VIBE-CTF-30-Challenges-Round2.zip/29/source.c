#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define DELTA 30

int main() {
    unsigned char enc[] = { 116, 103, 96, 99, 125, 97, 114, 100, 153, 114, 109, 140, 144, 96, 148, 130, 132, 98, 111, 105, 87, 106, 145, 132, 87, 155 };
    char secret[256];
    int i;
    for (i = 0; i < (int)(sizeof(enc)); i++)
        secret[i] = (char)((enc[i] - DELTA + 256) & 0xFF);
    secret[i] = '\0';

    char input[256];
    printf("Flag: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Incorrect.\n");
    fflush(stdout);
    exit(1);
}
