# Challenge 11

**Type:** Hex-encoded bytes in binary

## How to solve

The flag is stored as a **hex-encoded** ASCII string (e.g. `426f726f...` for "Bro...").

1. Run `strings unix/challenge` and look for a long string of hex digits (0–9, a–f).
2. Decode hex to text: `echo "PASTE_HEX" | xxd -r -p` or Python: `bytes.fromhex("PASTE_HEX").decode()`.
3. Submit the decoded flag.
