#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define DELTA 15

int main() {
    unsigned char enc[] = { 101, 88, 81, 84, 110, 82, 99, 85, 138, 116, 117, 125, 118, 103, 86, 98, 112, 72, 87, 116, 86, 94, 117, 84, 134, 140 };
    char secret[256];
    int i;
    for (i = 0; i < (int)(sizeof(enc)); i++)
        secret[i] = (char)((enc[i] - DELTA + 256) & 0xFF);
    secret[i] = '\0';

    char input[256];
    printf("Flag: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Incorrect.\n");
    fflush(stdout);
    exit(1);
}
