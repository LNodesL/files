#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    const char *secret = "VIBE_CTF{R8ai48DBpHQEPX6E}";
    char input[256];
    printf("Enter the flag to verify: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! Flag: %s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Wrong. Keep looking.\n");
    fflush(stdout);
    exit(1);
}
