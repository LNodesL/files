# Challenge 04

**Type:** XOR with single-byte key

## How to solve

The flag is **XOR-encoded** with a single-byte key. The encoded bytes and the key are both in the binary.

1. Find the **key**: a small integer (1–255) used in the binary (look for a constant or array of XOR results).
2. Find the **encoded byte array**: a list of integers in the binary (e.g. in `.rodata` or near the key).
3. Decode: for each byte `b`, the flag character is `b XOR key`. In Python: `bytes(b ^ key for b in enc).decode()`.
4. Submit the decoded flag.
