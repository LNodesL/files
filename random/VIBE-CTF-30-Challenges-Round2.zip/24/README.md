# Challenge 24

**Type:** Reversed string

## How to solve

The flag is stored **reversed** in the binary (e.g. `}9iHbO8xhnHGjini1{FTCrehtorB`).

1. Run `strings unix/challenge` and look for a string that starts with `}` and ends with `F` (or similar)—the reverse of `VIBE_CTF{...}`.
2. Reverse the string: Python: `"PASTE"[::-1]`, or output character by character in reverse.
3. Submit the reversed (correct) flag.
