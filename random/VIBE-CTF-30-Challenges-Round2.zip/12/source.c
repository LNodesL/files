#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

void hex_to_str(const char *hexstr, char *out, size_t max) {
    size_t j = 0;
    for (size_t i = 0; hexstr[i] && hexstr[i+1] && j < max; i += 2) {
        char a = hexstr[i], b = hexstr[i+1];
        if (!isxdigit((unsigned char)a) || !isxdigit((unsigned char)b)) break;
        int hi = isdigit(a) ? a - '0' : (tolower((unsigned char)a) - 'a' + 10);
        int lo = isdigit(b) ? b - '0' : (tolower((unsigned char)b) - 'a' + 10);
        out[j++] = (char)((hi << 4) | lo);
    }
    out[j] = '\0';
}

int main() {
    const char *hex_encoded = "564942455f4354467b533249673937434a39424d6d31544c357d";
    char secret[256];
    hex_to_str(hex_encoded, secret, sizeof(secret) - 1);

    char input[256];
    printf("Flag? ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Wrong.\n");
    fflush(stdout);
    exit(1);
}
