#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    const char *pass = "open_sesame_bZKAy7";
    unsigned char enc[] = { 63, 32, 43, 44, 54, 42, 61, 47, 18, 60, 30, 38, 14, 12, 19, 13, 38, 61, 11, 88, 63, 40, 90, 33, 42, 20 };
    unsigned char k = 105;
    char flag[256];
    int i;
    for (i = 0; i < (int)(sizeof(enc)); i++) flag[i] = (char)(enc[i] ^ k);
    flag[i] = '\0';

    char input[256];
    printf("Password: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, pass) == 0) {
        printf("Access granted. Flag: %%s\n", flag);
        fflush(stdout);
        exit(0);
    }
    printf("Access denied.\n");
    fflush(stdout);
    exit(1);
}
