#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    unsigned char enc[] = { 108, 115, 120, 127, 101, 121, 110, 124, 65, 2, 66, 78, 83, 109, 105, 75, 117, 9, 10, 112, 78, 87, 80, 83, 78, 71 };
    unsigned char key = 58;
    char secret[27];
    for (int i = 0; i < 26; i++) secret[i] = enc[i] ^ key;
    secret[26] = '\0';

    char input[256];
    printf("Key check: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Invalid.\n");
    fflush(stdout);
    exit(1);
}
