#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static char *b64decode(const char *in) {
    static char out[256];
    unsigned char buf[256];
    size_t i, j = 0, n = 0;
    static const char T[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    for (i = 0; in[i]; i++) {
        int v = (int)(strchr(T, in[i]) - T);
        if (v < 0) continue;
        switch (i % 4) {
            case 0: buf[n] = v << 2; break;
            case 1: buf[n++] |= v >> 4; buf[n] = (v & 15) << 4; break;
            case 2: buf[n++] |= v >> 2; buf[n] = (v & 3) << 6; break;
            case 3: buf[n++] |= v; break;
        }
    }
    buf[n] = '\0';
    for (j = 0; j < n; j++) out[j] = buf[j];
    out[n] = '\0';
    return out;
}

int main() {
    const char *encoded = "VklCRV9DVEZ7OVJBM1Vob1RvZmswOEdiSH0=";
    char *secret = b64decode(encoded);
    char input[256];
    printf("Verify flag: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Nope.\n");
    fflush(stdout);
    exit(1);
}
