# Challenge 08

**Type:** Base64-encoded in binary

## How to solve

The flag is stored as a **Base64-encoded** string in the binary.

1. Run `strings unix/challenge` (or the Windows executable) and look for a long alphanumeric string (possibly ending in `=` or `==`). Base64 uses A–Z, a–z, 0–9, `+`, `/`.
2. Decode the string: `echo -n "PASTE_STRING" | base64 -d` (Linux/macOS) or use an online decoder / Python: `import base64; base64.b64decode("PASTE_STRING").decode()`.
3. Submit the decoded flag.
