#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    char secret[27];
    secret[0] = 'V'; secret[1] = 'I'; secret[2] = 'B'; secret[3] = 'E'; secret[4] = '_'; secret[5] = 'C'; secret[6] = 'T'; secret[7] = 'F'; secret[8] = '{'; secret[9] = 'm'; secret[10] = 'u'; secret[11] = 'V'; secret[12] = 'x'; secret[13] = 'w'; secret[14] = 'J'; secret[15] = 'I'; secret[16] = 'I'; secret[17] = '1'; secret[18] = '7'; secret[19] = 'G'; secret[20] = 'C'; secret[21] = 'w'; secret[22] = 'U'; secret[23] = 'e'; secret[24] = 'X'; secret[25] = '}';
    secret[26] = '\0';

    char input[256];
    printf("Guess: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Wrong.\n");
    fflush(stdout);
    exit(1);
}
