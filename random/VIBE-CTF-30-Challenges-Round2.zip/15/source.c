#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

void rot13(char *s) {
    for (; *s; s++) {
        if (*s >= 'a' && *s <= 'z') *s = (char)((*s - 'a' + 13) % 26 + 'a');
        else if (*s >= 'A' && *s <= 'Z') *s = (char)((*s - 'A' + 13) % 26 + 'A');
    }
}

int main() {
    char secret[] = "IVOR_PGS{eYeh8LE8bozlN6QQ}";
    rot13(secret);

    char input[256];
    printf("Enter flag: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Incorrect.\n");
    fflush(stdout);
    exit(1);
}
