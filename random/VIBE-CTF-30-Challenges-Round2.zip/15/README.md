# Challenge 15

**Type:** ROT13 encoded

## How to solve

The flag is stored **ROT13-encoded** in the binary (each letter shifted by 13).

1. Run `strings unix/challenge` and find a string that looks like a mangled flag (e.g. `OebgureubaqPGS{...}`).
2. Decode ROT13: Linux/macOS: `echo "PASTE" | tr 'A-Za-z' 'N-ZA-Mn-za-m'`, or Python: `import codecs; codecs.decode("PASTE", "rot13")`.
3. Submit the decoded flag.
