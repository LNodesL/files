# Challenge 18

**Type:** Split across two buffers

## How to solve

The flag is **split into two byte arrays** and reassembled at runtime.

1. Open the binary in a disassembler (e.g. Ghidra, IDA) or inspect with `objdump -s -j .rodata unix/challenge`.
2. Find two arrays of small integers (0–255); they are often adjacent or in the same section.
3. Concatenate the bytes in order: first array, then second array. Convert to a string (e.g. Python: `bytes(arr1 + arr2).decode()`).
4. Submit the resulting flag.
