#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    unsigned char a[] = { 86, 73, 66, 69, 95, 67, 84, 70, 123, 107, 106, 65, 83 };
    unsigned char b[] = { 83, 84, 105, 54, 73, 89, 120, 85, 78, 75, 53, 70, 125 };
    char secret[256];
    int i, j = 0;
    for (i = 0; i < (int)(sizeof(a)); i++) secret[j++] = (char)a[i];
    for (i = 0; i < (int)(sizeof(b)); i++) secret[j++] = (char)b[i];
    secret[j] = '\0';

    char input[256];
    printf("Flag: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("No.\n");
    fflush(stdout);
    exit(1);
}
