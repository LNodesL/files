#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    char secret[27];
    secret[0] = 'V'; secret[1] = 'I'; secret[2] = 'B'; secret[3] = 'E'; secret[4] = '_'; secret[5] = 'C'; secret[6] = 'T'; secret[7] = 'F'; secret[8] = '{'; secret[9] = 'u'; secret[10] = 'b'; secret[11] = 'l'; secret[12] = 'E'; secret[13] = 'n'; secret[14] = 'T'; secret[15] = '2'; secret[16] = 't'; secret[17] = 'K'; secret[18] = 't'; secret[19] = 'A'; secret[20] = 'F'; secret[21] = 'r'; secret[22] = 'R'; secret[23] = 'x'; secret[24] = 'x'; secret[25] = '}';
    secret[26] = '\0';

    char input[256];
    printf("Guess: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Wrong.\n");
    fflush(stdout);
    exit(1);
}
