# Challenge 02

**Type:** Plain string in binary (strings/grep)

## How to solve

The flag is stored as a **plain string** inside the binary.

1. **Linux/macOS:** Run `strings unix/challenge` (or `strings windows/challenge.exe` on Windows) and look for text matching `VIBE_CTF{...}`.
2. **Alternative:** Open the binary in a hex editor or use `grep -a "VIBE_CTF" unix/challenge`.
3. Submit the full flag string (including `VIBE_CTF{` and `}`).
