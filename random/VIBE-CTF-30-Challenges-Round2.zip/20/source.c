#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    char secret[27];
    secret[0] = 'V'; secret[1] = 'I'; secret[2] = 'B'; secret[3] = 'E'; secret[4] = '_'; secret[5] = 'C'; secret[6] = 'T'; secret[7] = 'F'; secret[8] = '{'; secret[9] = 'u'; secret[10] = 'f'; secret[11] = 'y'; secret[12] = 'K'; secret[13] = '8'; secret[14] = 'A'; secret[15] = 'F'; secret[16] = '6'; secret[17] = 'w'; secret[18] = 'h'; secret[19] = 'b'; secret[20] = 'c'; secret[21] = 'X'; secret[22] = 'v'; secret[23] = 'E'; secret[24] = 'x'; secret[25] = '}';
    secret[26] = '\0';

    char input[256];
    printf("Guess: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Wrong.\n");
    fflush(stdout);
    exit(1);
}
