# Challenge 20

**Type:** Built on stack at runtime

## How to solve

The flag is **built on the stack at runtime** (no single contiguous string in the binary).

1. Run the program under a debugger (e.g. GDB, x64dbg) and set a breakpoint just before the comparison or before `printf("Correct!")`.
2. Alternatively, trace in a disassembler to find where bytes are written into a buffer (e.g. `mov` into stack).
3. After the buffer is fully built, inspect that memory (e.g. GDB: `x/s $rsp` or similar) to read the flag.
4. Submit the flag.
