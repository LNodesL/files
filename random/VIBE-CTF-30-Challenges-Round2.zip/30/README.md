# Challenge 30

**Type:** Add/subtract constant algorithm

## How to solve

The flag is encoded with a **simple algorithm**: each byte has a constant added (mod 256). A `DELTA` (or similar) constant is in the binary.

1. In a disassembler or with `objdump`, find the **encoded byte array** and the **DELTA** (or additive constant).
2. Decode: for each byte `b`, flag byte = `(b - DELTA + 256) % 256`. Python: `bytes((b - delta) % 256 for b in enc).decode()`.
3. Submit the decoded flag.
