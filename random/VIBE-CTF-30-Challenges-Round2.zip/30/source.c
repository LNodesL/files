#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define DELTA 13

int main() {
    unsigned char enc[] = { 99, 86, 79, 82, 108, 80, 97, 83, 136, 131, 97, 81, 120, 117, 121, 122, 61, 124, 101, 99, 102, 68, 86, 117, 125, 138 };
    char secret[256];
    int i;
    for (i = 0; i < (int)(sizeof(enc)); i++)
        secret[i] = (char)((enc[i] - DELTA + 256) & 0xFF);
    secret[i] = '\0';

    char input[256];
    printf("Flag: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, secret) == 0) {
        printf("Correct! %%s\n", secret);
        fflush(stdout);
        exit(0);
    }
    printf("Incorrect.\n");
    fflush(stdout);
    exit(1);
}
