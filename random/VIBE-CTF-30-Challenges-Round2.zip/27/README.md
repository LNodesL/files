# Challenge 27

**Type:** Password-protected (password in binary)

## How to solve

A **password** is stored in the binary; entering it causes the program to print the flag. The flag itself is XOR-encoded.

1. Find the **password**: run `strings unix/challenge` and look for a plausible password string (e.g. `open_sesame_...`).
2. Run the program and enter that password to get the flag printed.
3. **Alternatively:** find the XOR-encoded flag bytes and the key in the binary, decode as in the XOR challenge type, and submit without running the program.
4. Submit the flag (format `VIBE_CTF{...}`).
