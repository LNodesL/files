#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    const char *pass = "open_sesame_K50hUX";
    unsigned char enc[] = { 51, 44, 39, 32, 58, 38, 49, 35, 30, 85, 85, 1, 23, 60, 36, 32, 43, 44, 41, 93, 18, 50, 38, 49, 20, 24 };
    unsigned char k = 101;
    char flag[256];
    int i;
    for (i = 0; i < (int)(sizeof(enc)); i++) flag[i] = (char)(enc[i] ^ k);
    flag[i] = '\0';

    char input[256];
    printf("Password: ");
    fflush(stdout);
    if (!fgets(input, sizeof(input), stdin)) { fflush(stdout); exit(1); }
    input[strcspn(input, "\n")] = 0;
    if (strcmp(input, pass) == 0) {
        printf("Access granted. Flag: %%s\n", flag);
        fflush(stdout);
        exit(0);
    }
    printf("Access denied.\n");
    fflush(stdout);
    exit(1);
}
